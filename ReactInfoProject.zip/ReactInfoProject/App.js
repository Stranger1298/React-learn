import Header from './Components/Header.js';
import Maincontent from './Components/Main.js';
import Footer from './Components/Footer.js';

const App = () => (
    <div>
        <Header />
        <Maincontent />
        <Footer />
    </div>
);

const rootElement = document.getElementById('root');
ReactDOM.createRoot(rootElement).render(<App />);
export default App