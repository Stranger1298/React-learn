import React from 'react'
function Maincontent() {
    return (
        <div>
            <h2>Fun facts about React</h2>
            <p>Not a Framework, But a JavaScript Library</p>
            <p>Thriving Communities of Loyal Users</p>
            <p>Fast Speed of Virtual DOM</p>
            <p>Leading Front-End Development Tool</p>
        </div>
    );
}

export default Main