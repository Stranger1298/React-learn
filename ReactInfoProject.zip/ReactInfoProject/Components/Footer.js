import React from 'react'
function Footer() {
    return (
        <div>
            <p>© Copyright 2024. A project by Aman</p>
        </div>
    );
}

export default Footer